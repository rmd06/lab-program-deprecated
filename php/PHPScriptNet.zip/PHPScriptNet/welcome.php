<?php
/*
THIS SOFTWARE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER
EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
MERCHANTIBILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.

Copyrights (C) 2009 By DigitalCoding.Com

Visit our web site for more Free software downloads.
http://www.digitalcoding.com/

PHPScriptNet Welcome Page
*/
?>
<html>
<head>
<title>Welcome to PHPScriptNet</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<style>
<!--
table {
	font-family: Verdana, Arial, Helvetica, sans-serif;
	border-collapse: collapse;
	border-left: 1px solid #ccc;
	border-top: 1px solid #ccc; 
	color: #333;
}

table caption {
	font-size: 1.1em;
	font-weight: bold;
	letter-spacing: -1px;
	margin-bottom: 10px;
	padding: 5px;
	background: #efefef;
	border: 1px solid #ccc;
	color: #666;
}

table a {
	text-decoration: none;
	border-bottom: 1px dotted #f60;
	color: #f60;
	font-weight: bold;
}

table a:hover {
	text-decoration: none;
	color: #fff;
	background: #f60;
}

table tr th a {
	color: #369;
	border-bottom: 1px dotted #369;
}

table tr th a:hover {
	color: #fff;
	background: #369;
}

table thead tr th {
	text-transform: uppercase;
	background: #e2e2e2;
}

table tfoot tr th, table tfoot tr td {
	text-transform: uppercase;
	color: #000;
	font-weight: bold;
}

table tfoot tr th {
	width: 20%;
}

table tfoot tr td {
	width: 80%;
}

table td, table th {
	border-right: 1px solid #ccc;
	border-bottom: 1px solid #ccc;
	padding: 5px;
	line-height: 1.8em;
	font-size: 0.8em;
	vertical-align: top;
	width: 20%;
}

table tr.odd th, table tr.odd td {
	background: #efefef;
}
-->
</style>
</head>

<body>
<table align="center" width="100%">
<tr>
<td colspan="2" align="center"><h3>Welcome to PHPScriptNet</h3></td>
</tr>
<tr><td colspan="2" align="center">Download more webmaster tools at : <a target="_blank" href="http://www.digitalcoding.com/"><b>www.digitalcoding.com</b></a></td></tr>
<tr><td>PHP Version</td><td><?php echo phpversion(); ?></td></tr>
<tr><td valign="top">Working Folder</td><td><input name="workdir" type="text" id="workdir" value="<?php echo getcwd(); ?>" size="40" /></td></tr>
<tr><td>Computer Name</td><td><?php echo isset($_SERVER["COMPUTERNAME"])?$_SERVER["COMPUTERNAME"]:'N/A'; ?></td></tr>
<!--
<tr><td>Computer IP</td><td><?php echo isset($_SERVER["REMOTE_ADDR"])?$_SERVER["REMOTE_ADDR"]:'N/A'; ?></td></tr>
//-->
<tr><td>Operating System</td><td><?php echo isset($_SERVER["OS"])?$_SERVER["OS"]:'N/A'; ?></td></tr>
<tr><td>User Name</td><td><?php echo isset($_SERVER["USERNAME"])?$_SERVER["USERNAME"]:'N/A'; ?></td></tr>
<tr><td>User Domain</td><td><?php echo isset($_SERVER["USERDOMAIN"])?$_SERVER["USERDOMAIN"]:'N/A'; ?></td></tr>
<tr><td>User DNS Domain</td><td><?php echo isset($_SERVER["USERDNSDOMAIN"])?$_SERVER["USERDNSDOMAIN"]:'N/A'; ?></td></tr>
<tr><td>System Drive</td><td><?php echo isset($_SERVER["SystemDrive"])?$_SERVER["SystemDrive"]:'N/A'; ?></td></tr>
<tr><td valign="top">Available PHP Extensions</td><td>
<textarea name="extfiles" cols="30" rows="7" id="extfiles">
<?php 
// Set PHP Extension DIR
$dir = getcwd() . "\\PHP\\ext";
// Display all the extension in the Dir
if($handle = opendir($dir))
{
    while($file = readdir($handle))
    {
        if(is_file($dir . "\\" . $file))
            echo $file . "\r\n";
    }
    closedir($handle);
}
 ?>
</textarea></td></tr>
</table>
</body>
</html>
